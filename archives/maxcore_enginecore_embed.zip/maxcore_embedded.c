#include <stddef.h>

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

#include "maxcore_embedded.h"
#include "maxcore_embedded_source.h"

void MaxCore_Initialize(lua_State *L)
{
    int status = luaL_loadbuffer(
        L,
        (const char *)MAXCORE_LUA_SOURCE,
        MAXCORE_LUA_SOURCE_SIZE,
        "@embedded/max_core.lua"
    );

    if (status != LUA_OK) {
        /* Leave the loader error on the stack and raise it to the caller. */
        lua_error(L);
        return;
    }

    status = lua_pcall(L, 0, 1, 0);
    if (status != LUA_OK) {
        /* Leave the initialization error on the stack and raise it. */
        lua_error(L);
        return;
    }

    /* The Lua module still returns { call = call }; discard that result. */
    lua_pop(L, 1);

    /* Fail early if the core source did not publish the global correctly. */
    lua_getglobal(L, "EngineCore");
    if (!lua_istable(L, -1)) {
        lua_pop(L, 1);
        luaL_error(L, "embedded max_core.lua did not initialize global EngineCore");
        return;
    }

    lua_pop(L, 1);
}
