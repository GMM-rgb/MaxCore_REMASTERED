#ifndef MAXCORE_EMBEDDED_H
#define MAXCORE_EMBEDDED_H

#include "lua.h"

/*
 * Execute the embedded max_core.lua chunk.
 * Requires standard Lua libraries to have been opened first.
 * Raises a Lua error on load/initialization failure.
 */
void MaxCore_Initialize(lua_State *L);

#endif
