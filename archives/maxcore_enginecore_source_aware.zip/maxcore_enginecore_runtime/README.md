# MaxCore source-aware LuaLS metadata

This package uses a hybrid approach:

- `maxcore_bootstrap.c` continues loading `./max_core.lua` and injecting the actual global `EngineCore`.
- `generate_engine_meta.py` scans Lua files in the project and preserves source annotation blocks (`---@class`, `---@field`, `---@alias`, etc.) in `bin/game_engine_meta.lua`.
- Runtime-only members discovered by C are written separately to `bin/game_engine_runtime_meta.lua`, so runtime discovery cannot overwrite the source-derived signatures.

## Files

- `maxcore_bootstrap.c` / `.h`: runtime initializer and fallback metadata writer.
- `generate_engine_meta.py`: source annotation scanner.
- `CMAKE_PATCH.txt`: build-time generation wiring.

## Integration

1. Place `maxcore_bootstrap.c` and `.h` beside `lua.c` in the selected Lua `src` directory.
2. Place `generate_engine_meta.py` at the repository root (recommended) or update its CMake path to its actual location.
3. Add the CMake patch, making sure the source metadata command points to the real script path and uses the selected project root.
4. Configure/build. The generator writes `lua-<version>/bin/game_engine_meta.lua` based on the `MAXCORE_LUA_SRC_DIR` layout if you set output to `${LUA_SRC_DIR}/../bin`.
5. Add the generated `bin` directory to LuaLS `workspace.library` so the language server indexes the generated metadata.

The scanner preserves existing annotation blocks; it does not infer annotations that are absent from source. Runtime discovery is intentionally separate because Lua runtime inspection cannot recover parameter names/types discarded during compilation.
