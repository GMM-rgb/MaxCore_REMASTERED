#ifndef MAXCORE_BOOTSTRAP_H
#define MAXCORE_BOOTSTRAP_H

#include "lua.h"

/*
** Loads ./max_core.lua from the process working directory, initializes its
** call() function as the global EngineCore, and generates LuaLS metadata at
** <selected Lua version directory>/bin/game_engine_meta.lua.
** Raises a Lua error if loading, initialization, or metadata generation fails.
*/
void MaxCore_Initialize(lua_State *L);

#endif
