#!/usr/bin/env python3
"""Generate LuaLS metadata from Lua source annotations without executing the engine."""
from __future__ import annotations
import argparse
from pathlib import Path
import re

ANNOTATION = re.compile(r'^\s*---@(?:class|field|alias|generic|param|return|overload|type|enum|deprecated|nodiscard|version|see|diagnostic|operator|async|vararg|cast|meta|module|using|namespace|source|mapping|language|package|class|field)\b')
CLASS = re.compile(r'^\s*---@class\s+([\w.]+)')


def collect_annotations(root: Path, excluded: Path | None) -> list[str]:
    lines: list[str] = []
    seen: set[str] = set()
    for path in sorted(root.rglob('*.lua')):
        if excluded and (path == excluded or excluded in path.parents):
            continue
        # Avoid generated output and dependency/build trees.
        if any(part in {'bin', 'build', '.git', 'node_modules'} for part in path.parts):
            continue
        try:
            source = path.read_text(encoding='utf-8')
        except (OSError, UnicodeError):
            continue
        source_lines = source.splitlines()
        i = 0
        while i < len(source_lines):
            line = source_lines[i]
            if CLASS.match(line) or re.match(r'^\s*---@alias\b', line):
                block: list[str] = [line.strip()]
                i += 1
                while i < len(source_lines) and re.match(r'^\s*---@', source_lines[i]):
                    block.append(source_lines[i].strip())
                    i += 1
                text = '\n'.join(block)
                if text not in seen:
                    seen.add(text)
                    lines.extend(block)
                    lines.append('')
                continue
            i += 1
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    annotations = collect_annotations(root, output)
    # MaxCore is the class declared by max_core.lua. The live C bootstrap creates
    # the actual global; this assignment is a type-only declaration for LuaLS.
    content = [
        '---@meta',
        '-- Generated from Lua source annotations by generate_engine_meta.py.',
        '-- Runtime-only discoveries are emitted separately to game_engine_runtime_meta.lua.',
        '',
        *annotations,
        '---@type MaxCore',
        'EngineCore = {}',
        '',
    ]
    output.write_text('\n'.join(content), encoding='utf-8', newline='\n')
    print(f'[MaxCore] Generated source metadata: {output}')
    print(f'[MaxCore] Preserved {len(annotations)} annotation lines.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
